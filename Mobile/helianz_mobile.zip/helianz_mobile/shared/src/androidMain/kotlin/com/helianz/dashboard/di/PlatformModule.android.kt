package com.helianz.dashboard.di

import com.helianz.dashboard.di.sharedModule
import org.koin.core.context.startKoin

fun initKoin() {
    startKoin {
        modules(sharedModule)
    }
}
