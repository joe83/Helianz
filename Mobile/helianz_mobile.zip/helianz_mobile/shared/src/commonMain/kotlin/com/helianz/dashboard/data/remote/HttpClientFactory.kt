package com.helianz.dashboard.data.remote

import io.ktor.client.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.plugins.logging.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json

/**
 * Creates and configures the shared Ktor HttpClient.
 * Platform engines (OkHttp / Darwin) are injected via expect/actual.
 */
fun createHttpClient(): HttpClient {
    return HttpClient {
        // JSON serialization
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                isLenient = true
                prettyPrint = false
            })
        }

        // Logging (debug only)
        install(Logging) {
            logger = Logger.DEFAULT
            level = LogLevel.HEADERS
        }

        // Timeouts
        install(HttpTimeout) {
            requestTimeoutMillis = 15_000
            connectTimeoutMillis = 10_000
        }

        // Default request config
        defaultRequest {
            url("http://10.0.2.2:8000/") // Android emulator → host; configure per env
            headers.append("X-API-Key", "")
            headers.append("Content-Type", "application/json")
        }
    }
}
