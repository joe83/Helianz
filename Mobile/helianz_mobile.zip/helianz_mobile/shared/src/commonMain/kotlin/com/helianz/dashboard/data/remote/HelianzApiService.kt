package com.helianz.dashboard.data.remote

import com.helianz.dashboard.data.model.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.request.*

/**
 * API service for the Helianz dashboard.
 * Calls the dbt_dental_clinic FastAPI backend.
 */
class HelianzApiService(
    private val client: HttpClient,
    private val baseUrl: String = "http://10.0.2.2:8000"
) {

    // ── Dashboard ──────────────────────────────────────

    suspend fun getDashboardKpis(): DashboardKpi {
        return client.get("$baseUrl/reports/dashboard/").body()
    }

    // ── Revenue / Production ───────────────────────────

    suspend fun getRevenueTrends(
        startDate: String,
        endDate: String
    ): List<RevenueTrend> {
        return client.get("$baseUrl/reports/revenue/trends") {
            parameter("start_date", startDate)
            parameter("end_date", endDate)
        }.body()
    }

    suspend fun getDailyProductionByProcedure(
        startDate: String,
        endDate: String
    ): List<DailyProductionByProcedure> {
        return client.get("$baseUrl/reports/daily-production-by-procedure") {
            parameter("start_date", startDate)
            parameter("end_date", endDate)
        }.body()
    }

    // ── Payments ───────────────────────────────────────

    suspend fun getDailyPayments(
        startDate: String,
        endDate: String
    ): List<DailyPayment> {
        return client.get("$baseUrl/reports/daily-payments") {
            parameter("start_date", startDate)
            parameter("end_date", endDate)
        }.body()
    }

    // ── Providers ──────────────────────────────────────

    suspend fun getProviders(): List<ProviderSummary> {
        return client.get("$baseUrl/reports/providers/").body()
    }

    // ── Patients ───────────────────────────────────────

    suspend fun getPatients(
        page: Int = 1,
        limit: Int = 20
    ): List<PatientInfo> {
        return client.get("$baseUrl/patients/") {
            parameter("page", page)
            parameter("limit", limit)
        }.body()
    }

    suspend fun searchPatients(query: String): List<PatientInfo> {
        return client.get("$baseUrl/patients/search") {
            parameter("query", query)
        }.body()
    }

    // ── AR ─────────────────────────────────────────────

    suspend fun getArSummary(): ArAgingSummary {
        return client.get("$baseUrl/reports/ar/").body()
    }
}
