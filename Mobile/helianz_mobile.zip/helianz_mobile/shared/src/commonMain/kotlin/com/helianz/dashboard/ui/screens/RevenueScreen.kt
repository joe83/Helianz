package com.helianz.dashboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.helianz.dashboard.data.model.DailyPayment
import com.helianz.dashboard.data.model.DailyProductionByProcedure
import com.helianz.dashboard.data.model.RevenueTrend
import com.helianz.dashboard.domain.RevenueViewModel
import com.helianz.dashboard.ui.components.MetricRow
import com.helianz.dashboard.ui.components.formatRupiah
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RevenueScreen(
    viewModel: RevenueViewModel = koinViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    // Default: current month
    val now = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
    val defaultStart = "${now.year}-${now.monthNumber.toString().padStart(2, '0')}-01"
    val defaultEnd = "${now.year}-${now.monthNumber.toString().padStart(2, '0')}-${now.dayOfMonth.toString().padStart(2, '0')}"

    var startDate by remember { mutableStateOf(defaultStart) }
    var endDate by remember { mutableStateOf(defaultEnd) }

    LaunchedEffect(Unit) {
        viewModel.loadRevenue(startDate, endDate)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Produksi & Pembayaran") })
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            // Date filter
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = startDate,
                    onValueChange = { startDate = it },
                    label = { Text("Dari (YYYY-MM-DD)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = endDate,
                    onValueChange = { endDate = it },
                    label = { Text("Sampai") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.loadRevenue(startDate, endDate) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Tampilkan")
            }

            Spacer(Modifier.height(16.dp))

            when {
                state.isLoading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                state.error != null -> {
                    Text("Error: ${state.error}", color = MaterialTheme.colorScheme.error)
                }
                else -> {
                    var selectedTab by remember { mutableStateOf(0) }
                    TabRow(selectedTabIndex = selectedTab) {
                        Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Ringkasan") })
                        Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Per Prosedur") })
                        Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Pembayaran") })
                    }

                    when (selectedTab) {
                        0 -> RevenueSummaryTab(state.trends)
                        1 -> ProductionByProcedureTab(state.dailyProduction)
                        2 -> PaymentsTab(state.dailyPayments)
                    }
                }
            }
        }
    }
}

@Composable
private fun RevenueSummaryTab(trends: List<RevenueTrend>) {
    if (trends.isEmpty()) {
        Text("Tidak ada data untuk rentang ini.")
        return
    }
    val totalProd = trends.sumOf { it.production }
    val totalColl = trends.sumOf { it.collections }

    Column(Modifier.padding(top = 16.dp)) {
        MetricRow("Total Produksi", formatRupiah(totalProd))
        MetricRow("Total Koleksi", formatRupiah(totalColl))
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        LazyColumn {
            items(trends) { trend ->
                MetricRow(trend.date, "${formatRupiah(trend.production)} / ${formatRupiah(trend.collections)}")
            }
        }
    }
}

@Composable
private fun ProductionByProcedureTab(items: List<DailyProductionByProcedure>) {
    if (items.isEmpty()) {
        Text("Tidak ada data produksi.")
        return
    }
    LazyColumn {
        items(items) { item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(item.procedureDescription, style = MaterialTheme.typography.bodyLarge)
                    MetricRow("Kode", item.procedureCode)
                    MetricRow("Qty", "${item.quantity}")
                    MetricRow("Total", formatRupiah(item.totalProduction))
                }
            }
        }
    }
}

@Composable
private fun PaymentsTab(payments: List<DailyPayment>) {
    if (payments.isEmpty()) {
        Text("Tidak ada data pembayaran.")
        return
    }
    val totalNet = payments.sumOf { it.netCollections }

    Column(Modifier.padding(top = 16.dp)) {
        MetricRow("Net Koleksi (Periode)", formatRupiah(totalNet))
        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        LazyColumn {
            items(payments) { p ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.date, style = MaterialTheme.typography.labelMedium)
                        MetricRow("Pasien", formatRupiah(p.patientPayments))
                        MetricRow("Asuransi", formatRupiah(p.insurancePayments))
                        MetricRow("Net Koleksi", formatRupiah(p.netCollections))
                    }
                }
            }
        }
    }
}
