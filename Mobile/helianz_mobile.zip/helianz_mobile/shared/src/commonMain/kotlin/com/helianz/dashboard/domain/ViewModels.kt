package com.helianz.dashboard.domain

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.helianz.dashboard.data.model.*
import com.helianz.dashboard.data.repository.DashboardRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardUiState(
    val isLoading: Boolean = true,
    val kpis: DashboardKpi? = null,
    val error: String? = null
)

class DashboardViewModel(
    private val repository: DashboardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboard()
    }

    fun loadDashboard() {
        viewModelScope.launch {
            _uiState.value = DashboardUiState(isLoading = true)
            repository.getDashboardKpis()
                .onSuccess { kpis ->
                    _uiState.value = DashboardUiState(isLoading = false, kpis = kpis)
                }
                .onFailure { e ->
                    _uiState.value = DashboardUiState(isLoading = false, error = e.message)
                }
        }
    }
}

// ── Revenue ViewModel ──────────────────────────────────────

data class RevenueUiState(
    val isLoading: Boolean = true,
    val trends: List<RevenueTrend> = emptyList(),
    val dailyProduction: List<DailyProductionByProcedure> = emptyList(),
    val dailyPayments: List<DailyPayment> = emptyList(),
    val startDate: String = "",
    val endDate: String = "",
    val error: String? = null
)

class RevenueViewModel(
    private val repository: DashboardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(RevenueUiState())
    val uiState: StateFlow<RevenueUiState> = _uiState.asStateFlow()

    fun loadRevenue(startDate: String, endDate: String) {
        _uiState.value = _uiState.value.copy(
            isLoading = true, startDate = startDate, endDate = endDate
        )
        viewModelScope.launch {
            val trends = repository.getRevenueTrends(startDate, endDate)
            val production = repository.getDailyProduction(startDate, endDate)
            val payments = repository.getDailyPayments(startDate, endDate)

            val error = listOf(trends, production, payments)
                .filter { it.isFailure }
                .map { it.exceptionOrNull()?.message }
                .firstOrNull()

            _uiState.value = RevenueUiState(
                isLoading = false,
                trends = trends.getOrDefault(emptyList()),
                dailyProduction = production.getOrDefault(emptyList()),
                dailyPayments = payments.getOrDefault(emptyList()),
                startDate = startDate,
                endDate = endDate,
                error = error
            )
        }
    }
}

// ── Providers ViewModel ────────────────────────────────────

data class ProvidersUiState(
    val isLoading: Boolean = true,
    val providers: List<ProviderSummary> = emptyList(),
    val error: String? = null
)

class ProvidersViewModel(
    private val repository: DashboardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProvidersUiState())
    val uiState: StateFlow<ProvidersUiState> = _uiState.asStateFlow()

    init {
        loadProviders()
    }

    fun loadProviders() {
        viewModelScope.launch {
            _uiState.value = ProvidersUiState(isLoading = true)
            repository.getProviders()
                .onSuccess { providers ->
                    _uiState.value = ProvidersUiState(isLoading = false, providers = providers)
                }
                .onFailure { e ->
                    _uiState.value = ProvidersUiState(isLoading = false, error = e.message)
                }
        }
    }
}

// ── AR ViewModel ───────────────────────────────────────────

data class ArUiState(
    val isLoading: Boolean = true,
    val arSummary: ArAgingSummary? = null,
    val error: String? = null
)

class ArViewModel(
    private val repository: DashboardRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ArUiState())
    val uiState: StateFlow<ArUiState> = _uiState.asStateFlow()

    init {
        loadAr()
    }

    fun loadAr() {
        viewModelScope.launch {
            _uiState.value = ArUiState(isLoading = true)
            repository.getArSummary()
                .onSuccess { summary ->
                    _uiState.value = ArUiState(isLoading = false, arSummary = summary)
                }
                .onFailure { e ->
                    _uiState.value = ArUiState(isLoading = false, error = e.message)
                }
        }
    }
}
