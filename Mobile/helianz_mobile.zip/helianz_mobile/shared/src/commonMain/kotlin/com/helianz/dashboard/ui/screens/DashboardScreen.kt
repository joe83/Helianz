package com.helianz.dashboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.helianz.dashboard.domain.DashboardViewModel
import com.helianz.dashboard.ui.components.KpiCard
import com.helianz.dashboard.ui.components.formatCount
import com.helianz.dashboard.ui.components.formatPercent
import com.helianz.dashboard.ui.components.formatRupiah
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = koinViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Helianz Dashboard") })
        }
    ) { padding ->
        when {
            state.isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            state.error != null -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text("Gagal memuat data", color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { viewModel.loadDashboard() }) {
                            Text("Coba Lagi")
                        }
                    }
                }
            }
            state.kpis != null -> {
                val kpis = state.kpis!!
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Revenue row
                    Text("Pendapatan", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        KpiCard(
                            title = "Produksi Hari Ini",
                            value = formatRupiah(kpis.revenue.today),
                            modifier = Modifier.weight(1f)
                        )
                        KpiCard(
                            title = "Bulan Ini",
                            value = formatRupiah(kpis.revenue.thisMonth),
                            subtitle = "${if (kpis.revenue.percentChange >= 0) "+" else ""}${formatPercent(kpis.revenue.percentChange)} vs bln lalu",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Collections row
                    Text("Pembayaran", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        KpiCard(
                            title = "Koleksi Hari Ini",
                            value = formatRupiah(kpis.collections.today),
                            modifier = Modifier.weight(1f)
                        )
                        KpiCard(
                            title = "Bulan Ini",
                            value = formatRupiah(kpis.collections.thisMonth),
                            subtitle = "Rate: ${formatPercent(kpis.collections.collectionRate)}",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // AR row
                    Text("Piutang (AR)", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        KpiCard(
                            title = "Total AR",
                            value = formatRupiah(kpis.ar.totalAr),
                            modifier = Modifier.weight(1f),
                            valueColor = if (kpis.ar.over90Days > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                        KpiCard(
                            title = "> 90 Hari",
                            value = formatRupiah(kpis.ar.over90Days),
                            modifier = Modifier.weight(1f),
                            valueColor = MaterialTheme.colorScheme.error
                        )
                    }

                    // Appointments row
                    Text("Janji Temu", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        KpiCard(
                            title = "Terjadwal",
                            value = formatCount(kpis.appointments.scheduled),
                            modifier = Modifier.weight(1f)
                        )
                        KpiCard(
                            title = "Selesai",
                            value = formatCount(kpis.appointments.completed),
                            subtitle = "No-show: ${formatPercent(kpis.appointments.noShowRate)}",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // New patients
                    Text("Pasien Baru", style = MaterialTheme.typography.titleMedium)
                    KpiCard(
                        title = "Bulan Ini",
                        value = formatCount(kpis.newPatients.thisMonth),
                        subtitle = "Bln lalu: ${formatCount(kpis.newPatients.lastMonth)}"
                    )
                }
            }
        }
    }
}
