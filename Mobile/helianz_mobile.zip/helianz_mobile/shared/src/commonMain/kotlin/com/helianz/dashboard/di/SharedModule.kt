package com.helianz.dashboard.di

import com.helianz.dashboard.data.remote.HelianzApiService
import com.helianz.dashboard.data.repository.DashboardRepository
import com.helianz.dashboard.domain.*
import com.helianz.dashboard.data.remote.createHttpClient
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.module

val sharedModule = module {
    // HTTP client (platform engines injected via expect/actual)
    single { createHttpClient() }

    // API service
    single { HelianzApiService(get()) }

    // Repository
    singleOf(::DashboardRepository)

    // ViewModels
    factoryOf(::DashboardViewModel)
    factoryOf(::RevenueViewModel)
    factoryOf(::ProvidersViewModel)
    factoryOf(::ArViewModel)
}
