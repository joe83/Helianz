package com.helianz.dashboard.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// ── Dashboard KPIs ──────────────────────────────────────────
@Serializable
data class DashboardKpi(
    val revenue: RevenueKpi,
    val collections: CollectionsKpi,
    val ar: ArKpi,
    val appointments: AppointmentKpi,
    val newPatients: NewPatientKpi
)

@Serializable
data class RevenueKpi(
    val today: Double,
    val thisMonth: Double,
    val lastMonth: Double,
    val percentChange: Double
)

@Serializable
data class CollectionsKpi(
    val today: Double,
    val thisMonth: Double,
    val collectionRate: Double
)

@Serializable
data class ArKpi(
    val totalAr: Double,
    @SerialName("over_30_days") val over30Days: Double,
    @SerialName("over_60_days") val over60Days: Double,
    @SerialName("over_90_days") val over90Days: Double
)

@Serializable
data class AppointmentKpi(
    val scheduled: Int,
    val completed: Int,
    val noShowRate: Double
)

@Serializable
data class NewPatientKpi(
    val thisMonth: Int,
    val lastMonth: Int
)

// ── Revenue / Production ────────────────────────────────────
@Serializable
data class RevenueTrend(
    val date: String,
    val production: Double,
    val collections: Double,
    @SerialName("net_income") val netIncome: Double
)

@Serializable
data class DailyProductionByProcedure(
    val date: String,
    @SerialName("procedure_code") val procedureCode: String,
    @SerialName("procedure_description") val procedureDescription: String,
    val quantity: Int,
    @SerialName("total_production") val totalProduction: Double
)

// ── Daily Payments ──────────────────────────────────────────
@Serializable
data class DailyPayment(
    val date: String,
    @SerialName("patient_payments") val patientPayments: Double,
    @SerialName("insurance_payments") val insurancePayments: Double,
    @SerialName("total_income") val totalIncome: Double,
    @SerialName("total_production") val totalProduction: Double,
    @SerialName("total_writeoffs") val totalWriteoffs: Double,
    @SerialName("net_collections") val netCollections: Double
)

// ── Provider ────────────────────────────────────────────────
@Serializable
data class ProviderSummary(
    val id: Long,
    val name: String,
    val abbreviation: String?,
    val production: Double,
    val collections: Double,
    @SerialName("patient_count") val patientCount: Int,
    @SerialName("procedure_count") val procedureCount: Int
)

// ── Patient ─────────────────────────────────────────────────
@Serializable
data class PatientInfo(
    val id: Long,
    @SerialName("first_name") val firstName: String,
    @SerialName("last_name") val lastName: String?,
    @SerialName("birth_date") val birthDate: String?,
    @SerialName("last_visit_date") val lastVisitDate: String?,
    @SerialName("total_production") val totalProduction: Double?,
    @SerialName("outstanding_balance") val outstandingBalance: Double?
)

// ── AR Aging ────────────────────────────────────────────────
@Serializable
data class ArAgingSummary(
    @SerialName("total_outstanding") val totalOutstanding: Double,
    @SerialName("current_amount") val currentAmount: Double,
    @SerialName("days_1_30") val days1to30: Double,
    @SerialName("days_31_60") val days31to60: Double,
    @SerialName("days_61_90") val days61to90: Double,
    @SerialName("over_90_days") val over90Days: Double
)

// ── API wrapper ─────────────────────────────────────────────
@Serializable
data class ApiResponse<T>(
    val data: T? = null,
    val detail: String? = null
)
