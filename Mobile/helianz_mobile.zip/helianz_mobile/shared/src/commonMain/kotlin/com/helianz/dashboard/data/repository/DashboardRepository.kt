package com.helianz.dashboard.data.repository

import com.helianz.dashboard.data.model.*
import com.helianz.dashboard.data.remote.HelianzApiService

/**
 * Repository that wraps API calls and could add caching/offline support later.
 */
class DashboardRepository(
    private val api: HelianzApiService
) {
    suspend fun getDashboardKpis(): Result<DashboardKpi> = runCatching {
        api.getDashboardKpis()
    }

    suspend fun getRevenueTrends(start: String, end: String): Result<List<RevenueTrend>> = runCatching {
        api.getRevenueTrends(start, end)
    }

    suspend fun getDailyProduction(start: String, end: String): Result<List<DailyProductionByProcedure>> = runCatching {
        api.getDailyProductionByProcedure(start, end)
    }

    suspend fun getDailyPayments(start: String, end: String): Result<List<DailyPayment>> = runCatching {
        api.getDailyPayments(start, end)
    }

    suspend fun getProviders(): Result<List<ProviderSummary>> = runCatching {
        api.getProviders()
    }

    suspend fun getPatients(page: Int = 1): Result<List<PatientInfo>> = runCatching {
        api.getPatients(page)
    }

    suspend fun getArSummary(): Result<ArAgingSummary> = runCatching {
        api.getArSummary()
    }
}
