package com.helianz.dashboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.helianz.dashboard.domain.ArViewModel
import com.helianz.dashboard.ui.components.MetricRow
import com.helianz.dashboard.ui.components.formatRupiah
import org.koin.compose.viewmodel.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArScreen(
    viewModel: ArViewModel = koinViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Piutang (AR)") })
        }
    ) { padding ->
        when {
            state.isLoading -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            state.error != null -> {
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                        Text("Gagal memuat data", color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { viewModel.loadAr() }) {
                            Text("Coba Lagi")
                        }
                    }
                }
            }
            state.arSummary != null -> {
                val ar = state.arSummary!!
                Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)
                ) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Total Piutang", style = MaterialTheme.typography.labelMedium)
                            Text(
                                formatRupiah(ar.totalOutstanding),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("Aging Piutang", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))

                    MetricRow("Lancar (0 hari)", formatRupiah(ar.currentAmount))
                    HorizontalDivider()
                    MetricRow("1 - 30 hari", formatRupiah(ar.days1to30))
                    HorizontalDivider()
                    MetricRow("31 - 60 hari", formatRupiah(ar.days31to60))
                    HorizontalDivider()
                    MetricRow("61 - 90 hari", formatRupiah(ar.days61to90))
                    HorizontalDivider()
                    MetricRow(
                        "> 90 hari",
                        formatRupiah(ar.over90Days),
                        modifier = Modifier.let { it }
                    )
                    // Override color for >90 days
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("> 90 hari", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                        Text(formatRupiah(ar.over90Days), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
