package com.helianz.dashboard.app

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.helianz.dashboard.ui.screens.*
import com.helianz.dashboard.ui.theme.HelianzTheme

enum class Screen(val label: String, val icon: @Composable () -> Unit) {
    Dashboard("Dashboard", { Icon(Icons.Default.Home, contentDescription = "Dashboard") }),
    Revenue("Produksi", { Icon(Icons.Default.TrendingUp, contentDescription = "Revenue") }),
    Providers("Dokter", { Icon(Icons.Default.Person, contentDescription = "Providers") }),
    AR("Piutang", { Icon(Icons.Default.AccountBalance, contentDescription = "AR") })
}

@Composable
fun HelianzApp() {
    HelianzTheme {
        var selectedScreen by remember { mutableStateOf(Screen.Dashboard) }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    Screen.entries.forEach { screen ->
                        NavigationBarItem(
                            selected = selectedScreen == screen,
                            onClick = { selectedScreen = screen },
                            icon = screen.icon,
                            label = { Text(screen.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding)) {
                when (selectedScreen) {
                    Screen.Dashboard -> DashboardScreen()
                    Screen.Revenue -> RevenueScreen()
                    Screen.Providers -> ProvidersScreen()
                    Screen.AR -> ArScreen()
                }
            }
        }
    }
}
