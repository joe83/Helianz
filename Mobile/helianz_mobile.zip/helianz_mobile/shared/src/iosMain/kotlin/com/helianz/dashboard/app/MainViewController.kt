package com.helianz.dashboard.app

import androidx.compose.ui.window.ComposeUIViewController

/**
 * iOS entry point — creates a UIViewController hosting the shared Compose UI.
 */
fun MainViewController() = ComposeUIViewController {
    HelianzApp()
}
