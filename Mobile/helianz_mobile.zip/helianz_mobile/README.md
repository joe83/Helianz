# Helianz Dashboard — Mobile App (Kotlin Multiplatform)

Management dashboard for Helianz dental practice — read-only analytics for Android & iOS.

## Architecture

```
helianz_mobile/
├── shared/                        # KMP shared module
│   └── src/
│       ├── commonMain/            # Shared: models, API, ViewModels, Compose UI
│       │   └── kotlin/com/helianz/dashboard/
│       │       ├── app/           # HelianzApp.kt — main composable + navigation
│       │       ├── data/
│       │       │   ├── model/     # API response models
│       │       │   ├── remote/    # Ktor HTTP client + API service
│       │       │   └── repository/ # Repository pattern
│       │       ├── domain/        # ViewModels
│       │       ├── di/            # Koin dependency injection
│       │       └── ui/
│       │           ├── theme/     # Material 3 theme
│       │           ├── components/ # KpiCard, MetricRow, formatters
│       │           └── screens/   # Dashboard, Revenue, Providers, AR
│       ├── androidMain/           # Android Koin init
│       └── iosMain/               # iOS Koin init + MainViewController
├── androidApp/                    # Android application module
└── iosApp/                        # iOS application (SwiftUI host)
```

## Backend

This app calls the **dbt_dental_clinic FastAPI** backend. The API serves read-only analytics endpoints:

| Endpoint | Screen |
|----------|--------|
| `GET /reports/dashboard/` | Dashboard KPIs |
| `GET /reports/revenue/trends` | Revenue/Production trends |
| `GET /reports/daily-production-by-procedure` | Production by procedure |
| `GET /reports/daily-payments` | Daily payment detail |
| `GET /reports/providers/` | Provider performance |
| `GET /reports/ar/` | AR aging |

## Prerequisites

- **Android Studio** (Hedgehog or newer) with Android SDK 35
- **Xcode 16+** (macOS only, for iOS builds)
- **JDK 17**
- **dbt_dental_clinic** backend running (see that repo's README)

## Quick Start

### 1. Configure API URL

Edit `shared/src/commonMain/kotlin/com/helianz/dashboard/data/remote/HelianzApiService.kt`:
- Android emulator: `http://10.0.2.2:8000` (default)
- Physical device: your machine's LAN IP
- Production: your deployed API URL

### 2. Android

```bash
# Open in Android Studio
# Or via command line:
./gradlew :androidApp:installDebug
```

### 3. iOS (macOS only)

```bash
# Open iosApp/iosApp.xcodeproj in Xcode
# Build and run on simulator or device
```

## Tech Stack

| Layer | Library |
|-------|---------|
| UI | Compose Multiplatform (Material 3) |
| HTTP | Ktor Client |
| JSON | kotlinx.serialization |
| DI | Koin |
| Navigation | Custom tab-based (bottom nav) |
| Architecture | MVVM (ViewModel + StateFlow) |

## Relationship to helianz_qris_mirror_kotlin

This is a **separate app** from the QRIS mirror. The QRIS app is a single-purpose Android app for payment QR display. This dashboard is a full cross-platform analytics app for practice management.

Future: these could share a common `shared` module with data models and API client, but for now they remain independent.
